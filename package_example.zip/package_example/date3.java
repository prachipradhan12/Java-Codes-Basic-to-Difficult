import static aaj.ki.*;
class date3{

public static void main(String args[]){

tarikh();


}

}
class usecase1{

public static void main(String args[]){

snehamath.mymath.square(5);
snehamath.mymath.cube(4);

}

}
package p2.s2;

public class c2{

public String m2(String s1 , String s2){

String res = s1  +  " AND "  +  s2;
return res; 
}

}
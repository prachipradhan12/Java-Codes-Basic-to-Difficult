package snehamath;

public class mymath{

public static void square(double num){
double res=num*num;
System.out.println("square = " + res);
}

public static void cube(double num){
double res=num*num*num;
System.out.println("Cube = " + res);
}
}
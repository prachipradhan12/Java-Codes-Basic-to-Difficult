package aaj;
import java.util.*;
public class ki{

public static void tarikh(){

Date d = new Date();
System.out.println(d);

}

}
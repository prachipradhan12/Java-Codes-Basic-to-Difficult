import aaj.*;
class date2{

public static void main(String args[]){

ki.tarikh();


}

}
import p2.s2.c2;
class pkg3{

public static void main(String args[]){

c2 c= new 	c2();
String r=c.m2("sneha " ," indulkar");
System.out.println(r);
}

}
class pkg1{

public static void main(String args[]){

p2.s2.c2 c= new p2.s2.c2();
String r=c.m2("sneha " ," indulkar");
System.out.println(r);
}

}
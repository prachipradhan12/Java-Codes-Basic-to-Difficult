import static snehamath.mymath.*;
class usecase3{

public static void main(String args[]){

square(5);
cube(4);

}

}
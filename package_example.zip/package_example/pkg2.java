import p2.s2.*;
class pkg2{

public static void main(String args[]){

c2 c= new 	c2();
String r=c.m2("sneha " ," indulkar");
System.out.println(r);
}

}
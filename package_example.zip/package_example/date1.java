class date1{

public static void main(String args[]){

aaj.ki.tarikh();


}

}
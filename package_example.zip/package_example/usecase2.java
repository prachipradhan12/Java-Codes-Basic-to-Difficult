import snehamath.*;
class usecase2{

public static void main(String args[]){

mymath.square(5);
mymath.cube(4);

}

}